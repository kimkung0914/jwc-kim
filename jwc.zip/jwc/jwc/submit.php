
<?php

$text = $_POST['name'];
echo "NAME" . $text ;
echo "<br>";
$text = $_POST['commen' ] ; 
echo "Commen" . $text;

    
    ?>
    
